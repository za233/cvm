The "src/resources/images" directory is intended to hold all image/icon files used by
this module.
